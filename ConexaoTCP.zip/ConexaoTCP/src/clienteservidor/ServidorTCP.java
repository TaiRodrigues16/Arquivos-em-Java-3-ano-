package clienteservidor;

import java.awt.List;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Scanner;

public class ServidorTCP {
	
	public static long[] chavePublica = new long[2];
	public static long[] chavePrivada = new long[2];
	public static long[] chavePublicaCliente = new long[2];

	public static void main(String[] args) throws IOException {
		System.out.println("Gerando chaves...");
		RSA rsa = new RSA();
		chavePublica[0] = rsa.getE();
		chavePublica[1] = rsa.getN();
		chavePrivada[0] = rsa.getD();
		chavePrivada[1] = rsa.getN();
		try 
		{
			ArrayList<Socket> clientes = new ArrayList<Socket>();
			ServerSocket servidor = new ServerSocket(12345);
			System.out.println("Servidor ouvindo a porta 12345");
			RecebeConexaoClientes recebeConexao = new RecebeConexaoClientes(servidor, clientes);
			recebeConexao.start();
			
		} catch (Exception e) 
		{
			// TODO: handle exception
		}

	}

}
