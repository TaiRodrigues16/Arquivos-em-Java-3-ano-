package clienteservidor;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class RecebeConexaoClientes extends Thread
{
	ServerSocket servidor;
	ArrayList<Socket> listaDeClientes;
	
	public RecebeConexaoClientes(ServerSocket s, ArrayList<Socket> l) 
	{
		servidor = s;
		listaDeClientes = l;
	}
	
	@Override
	public void run() 
	{
		while(true)
		{
			try {
				Socket cliente = servidor.accept();
				System.out.println("Cliente conectado: " + cliente.getInetAddress().getHostAddress());
				RecebeMsgServidor recebeMsg = new RecebeMsgServidor(cliente);
				recebeMsg.start();
				EnviaMsgServidor enviaMsg = new EnviaMsgServidor(cliente);
				enviaMsg.run();
				listaDeClientes.add(cliente);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
