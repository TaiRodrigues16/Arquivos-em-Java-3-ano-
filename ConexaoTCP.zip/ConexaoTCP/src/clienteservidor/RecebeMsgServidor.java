package clienteservidor;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Socket;

public class RecebeMsgServidor extends Thread
{
	Socket cliente;
	
	public RecebeMsgServidor(Socket s) 
	{
		cliente = s;
	}
	
	@Override
	public void run() 
	{
		super.run();
		
		try{
			ObjectInputStream entradaChave = new ObjectInputStream(cliente.getInputStream());
			String chave = (String)entradaChave.readObject();
			ServidorTCP.chavePublicaCliente[0] = Long.parseLong(chave.trim().split(",")[0]);
			ServidorTCP.chavePublicaCliente[1] = Long.parseLong(chave.trim().split(",")[1]);
			System.out.println("Chave publica recebida: " + chave);
		}catch(Exception e){
			e.printStackTrace();
		}
		
		while(true)
		{
			try {
				ObjectInputStream entrada = new ObjectInputStream(cliente.getInputStream());
				String msg = (String) entrada.readObject();
				String msgDescript = RSA.descriptografar(ServidorTCP.chavePrivada[0], ServidorTCP.chavePrivada[1], msg);
				System.out.println(msgDescript);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
