package clienteservidor;

import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Scanner;

public class EnviaMsgServidor extends Thread
{
	Socket cliente;
	
	public EnviaMsgServidor(Socket c)
	{
		cliente = c;
	}
	
	@Override
	public void run() 
	{
		try{
			
			System.out.println("Enviando chave...");
			ObjectOutputStream saidaChave = new ObjectOutputStream(cliente.getOutputStream());
			saidaChave.flush();
			saidaChave.writeObject(ServidorTCP.chavePublica[0] + "," + ServidorTCP.chavePublica[1]);
			saidaChave.flush();
		}catch(Exception e){
			e.printStackTrace();
		}
		
		while(true)
		{
			try 
			{
				ObjectOutputStream saida = new ObjectOutputStream(cliente.getOutputStream());
				saida.flush();
				Scanner scan = new Scanner(System.in);
				String msg = scan.nextLine();
				String msgCrip = RSA.criptografar(ServidorTCP.chavePublicaCliente[0], ServidorTCP.chavePublicaCliente[1], msg);
				saida.writeObject(msgCrip);
				saida.flush();
			} catch (Exception e)
			{
				e.printStackTrace();
			}
		}
	}
}
