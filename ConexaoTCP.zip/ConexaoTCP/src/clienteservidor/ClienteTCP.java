package clienteservidor;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Scanner;

public class ClienteTCP {

	public static long[] chavePublica = new long[2];
	public static long[] chavePrivada = new long[2];
	public static long[] chavePublicaServidor = new long[2];
	
	public static void main(String[] args) {
		try 
		{
			System.out.println("Gerando chaves...");
			RSA rsa = new RSA();
			chavePublica[0] = rsa.getE();
			chavePublica[1] = rsa.getN();
			chavePrivada[0] = rsa.getD();
			chavePrivada[1] = rsa.getN();
			
			Socket cliente = new Socket("localhost", 12345);
			RecebeMsgCliente recebeMsg = new RecebeMsgCliente(cliente);
			
			recebeMsg.start();
			
			try{
				
				System.out.println("Enviando chave...");
				ObjectOutputStream saidaChave = new ObjectOutputStream(cliente.getOutputStream());
				saidaChave.flush();
				saidaChave.writeObject(chavePublica[0] + "," + chavePublica[1]);
				saidaChave.flush();
			}catch(Exception e){
				e.printStackTrace();
			}
			
			while(true)
			{				
				ObjectOutputStream saida = new ObjectOutputStream(cliente.getOutputStream());
				saida.flush();
				Scanner scan = new Scanner(System.in);
				String msg = scan.nextLine();
				String msgCrip = RSA.criptografar(chavePublicaServidor[0],chavePublicaServidor[1], msg);
				saida.writeObject(msgCrip);
				saida.flush();
				
				
			}
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}

	}

}
