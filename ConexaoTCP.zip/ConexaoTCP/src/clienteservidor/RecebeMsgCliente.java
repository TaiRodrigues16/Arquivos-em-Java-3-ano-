package clienteservidor;

import java.io.ObjectInputStream;
import java.net.Socket;

public class RecebeMsgCliente extends Thread
{
	Socket cliente;
	
	public RecebeMsgCliente(Socket s) 
	{
		cliente = s;
	}
	
	@Override
	public void run() 
	{
		super.run();
		
		try{
			ObjectInputStream entradaChave = new ObjectInputStream(cliente.getInputStream());
			String chave = (String)entradaChave.readObject();
			ClienteTCP.chavePublicaServidor[0] = Long.parseLong(chave.trim().split(",")[0]);
			ClienteTCP.chavePublicaServidor[1] = Long.parseLong(chave.trim().split(",")[1]);
			System.out.println("Chave publica recebida: " + chave);
		}catch(Exception e){
			e.printStackTrace();
		}
		
		while(true)
		{
			try
			{
				ObjectInputStream entrada = new ObjectInputStream(cliente.getInputStream());
				String msg = (String )entrada.readObject();
				String msgDescript = RSA.descriptografar(ClienteTCP.chavePrivada[0], ClienteTCP.chavePrivada[1], msg);
				System.out.println(msgDescript);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	}
}
