package calculadora;

public class Calculadora {
	
	Calculadora cal;
	
	private int somar;
	private int subtrair;
	private int dividir;
	private int multiplicar;
	
	private int num1;
	private int num2;
	private int result;
	
	public Calculadora(){
		this.num1 = 0;
		this.num2 = 0;
	}
	
	public int somar(){
		somar = num1 + num2;
		result = somar;
		return result;
	}
	
	public int getSomar(){
		return this.somar;
	}
	
	public int subtrair(){
		subtrair = num1 - num2;
		result = subtrair;
		return result;
	}
	
	public int getSubtrair(){
		return this.subtrair;
	}
	
	public int dividir(){
		dividir = num1 / num2;
		result = dividir;
		return result;
	}
	
	public int getDividir(){
		return this.dividir;
	}
	
	public int multiplicar(){
		multiplicar = num1 + num2;
		result = multiplicar;
		return result;
	}
	
	public int getMultiplicar(){
		return this.multiplicar;
	}
	
	public void imprimir(){
		System.out.println("Num1: " + this.num1);
		System.out.println("Num2: " + this.num2);
		System.out.println("Result: " + this.result);
		System.out.println("Result: " + this.somar());
	}

}
