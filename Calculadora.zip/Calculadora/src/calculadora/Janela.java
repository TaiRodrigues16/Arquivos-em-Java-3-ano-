package calculadora;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Janela extends JFrame{
	
	//Calculadora cal;
	
	private JLabel lblNum1, lblNum2, lblResult;
	private JButton btnSom, btnSub, btnDiv, btnMult;
	private JTextField txtNum1,txtNum2;
	
	public Janela(){
		this.setSize(410,250);
		this.setLayout(null);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		String titulo = null;
		this.setTitle("Calculadora");
		//Criando o circuito da Televis�o
		//cal = new Calculadora();
		
		this.preencheJanela();
		
		// T�m de ser o �ltimo comando
		this.setVisible(true);
	}

	private void preencheJanela() {
		
		JPanel panel = new JPanel();
		this.getContentPane().add(panel);
		panel.setLayout(null);
		panel.setBounds(0, 0, 410, 250);
		panel.setBackground(Color.lightGray);
		
		lblNum1 = new JLabel("Digite o 1� num: ");
		lblNum1.setBounds(10, 20, 100, 25);
		panel.add(lblNum1);
		//lblNum1.setVisible(true);
		
		txtNum1 = new JTextField();
		txtNum1.setBounds(110, 20, 30, 25);
		panel.add(txtNum1);
		
		lblNum2 = new JLabel("Digite o 2� num: ");
		lblNum2.setBounds(10, 50, 100, 25);
		panel.add(lblNum2);
		//lblNum2.setVisible(true);
		
		txtNum2 = new JTextField();
		txtNum2.setBounds(110, 50, 30, 25);
		panel.add(txtNum2);
		
		lblResult = new JLabel("Resultado: ");
		lblResult.setBounds(10, 100, 100, 25);
		panel.add(lblResult);
		//lblNum2.setVisible(true);
		
		btnSom = new JButton("Somar");
		btnSom.setBounds(5, 150, 80, 25);
		panel.add(btnSom);
		
		btnSom.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				double num1 = Double.parseDouble(txtNum1.getText());
				double num2 = Double.parseDouble(txtNum2.getText());
				double soma;
				
				soma = num1 + num2;
				
				lblResult.setText("Resultado: " + soma);
				
				//txtNum1.setText(null);
				//txtNum2.setText(null);
			}
		});
		
		btnSub = new JButton("Subtrair");
		btnSub.setBounds(95, 150, 90, 25);
		panel.add(btnSub);
		
		btnSub.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				double num1 = Double.parseDouble(txtNum1.getText());
				//int num1 = Integer.parseInt(txtNum1.getText()); 				//(!Quando se � em int!)\\
				double num2 = Double.parseDouble(txtNum2.getText());
				double subtrair;
				
				subtrair = num1 - num2;
				
				lblResult.setText("Resultado: " + subtrair);
				
				//txtNum1.setText(null);
				//txtNum2.setText(null);
				
			}
		});
		
		btnMult = new JButton("Multiplicar");
		btnMult.setBounds(190, 150, 100, 25);
		panel.add(btnMult);
		
		btnMult.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				double num1 = Double.parseDouble(txtNum1.getText());
				double num2 = Double.parseDouble(txtNum2.getText());
				double mult;
				
				mult = num1 * num2;
				
				lblResult.setText("Resultado: " + mult);
				
				//txtNum1.setText(null);
				//txtNum2.setText(null);
				
			}
		});
		
		btnDiv = new JButton("Dividir");
		btnDiv.setBounds(295, 150, 90, 25);
		panel.add(btnDiv);
		
		btnDiv.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				double num1 = Double.parseDouble(txtNum1.getText());
				double num2 = Double.parseDouble(txtNum2.getText());
				double div;
				
				div = num1 / num2;
				
				lblResult.setText("Resultado: " + div);
				
				//txtNum1.setText(null);
				//txtNum2.setText(null);
			}
		});
		
	}

}
