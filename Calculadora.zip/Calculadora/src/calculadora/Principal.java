package calculadora;

public class Principal {

	public static void main(String[] args) {
		
		/*Calculadora calc = new Calculadora();
		calc.multiplicar();
		calc.imprimir(); */
		
		Janela janela = new Janela();
		
	}

}
