package trabCripto;

import java.io.IOException;
import java.math.BigInteger;

public class Principal {

	public static void main(String[] args) throws IOException {
		
		String text = "tai";
		long e, n;
		
		BigInteger.valueOf(e);
		BigInteger.valueOf(n);
		
		BigInteger num = new BigInteger(text,2);
		
		num.modPow(e, n);

	}

}
