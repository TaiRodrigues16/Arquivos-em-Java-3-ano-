package classes;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Principal {

	public static void main(String[] args) throws IOException {
		
		File arq = new File("Arquivo/primos.txt");
		BufferedReader lerArquivo = new BufferedReader(new FileReader(arq));
	
		String linha = "";
		int contPrimos = 0;
		
		while(linha != null)
		{
			linha = lerArquivo.readLine();
			contPrimos++;
		}
		
		System.out.println(contPrimos);
		
		//String text= "oi";
		

}

}
