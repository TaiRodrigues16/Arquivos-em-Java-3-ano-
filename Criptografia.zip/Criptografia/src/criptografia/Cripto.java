package criptografia;

public class Cripto {
	
	private int chave;
	
	public Cripto(int chave){
		this.chave = chave;
	}
	
	public String criptografar(String msg){
		String msgCriptografada = "";
		//lenght serve para pegar o tamanho da mensagem e passar como parametro no for
		
		for (int i = 0; i < msg.length(); i++) {
			if(msg.charAt(i) != ' '){
				int letra = (int)msg.charAt(i);
				//cache(convers�o) transformar inteiro do meu caracter e tranforma em letra
				letra += chave;
				if(letra >= 97 && letra<= 122){
					msgCriptografada += (char)letra;
				}
				else{
					letra = (letra - 122) + 96;
					msgCriptografada += (char)letra;
				}
			}
			else msgCriptografada += ' ';
		}
		return msgCriptografada;
	}
	
	public String descriptografia(String msg){
		String msgCriptografada = "";
		
		for (int i = 0; i < msg.length(); i++) {
			if(msg.charAt(i) != ' '){
				int letra = (int)msg.charAt(i);
				//cache(convers�o) transformar inteiro do meu caracter e tranforma em letra
				letra -= chave;
				if(letra < 97){
					letra = (96 - letra) + 122;
				}
				msgCriptografada += (char)letra;
			}
			else msgCriptografada += ' ';
		}
		return msgCriptografada;
	}

}