package criptografia;

import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		
		//Cripto c = new Cripto(1);
		//System.out.println(c.criptografar("teste"));
		
		System.out.println("Digite sua mensagem: ");
		Scanner scan = new Scanner(System.in);
		String msg = scan.nextLine();
		
		Cripto c = new Cripto(1);
		
		String criptografar = c.criptografar(msg);
		String descriptografar = c.descriptografia(criptografar);
		
		System.out.println(criptografar);
		System.out.println(descriptografar);

	}

}
