package prova;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Prova extends JFrame {
	
	private JTextField txtConteudo;
	private JButton btnEnviar, btnCopiar, btnLimpar1, btnLimpar2;
	private JTextArea txtA, txtB;
	
public Prova(String titulo){
		
		this.setLayout(null);
		
		this.setSize(400, 300);
		
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	
		this.setTitle(titulo);
		
		this.preencheJanela();
		
		this.setVisible(true);
	
	}

public void preencheJanela(){
	
	txtConteudo = new JTextField();
	txtConteudo.setBounds(10, 20, 200, 25);
	this.add(txtConteudo);
	
	txtA = new JTextArea();
	txtA.setBounds(10, 50, 150, 100);
	this.add(txtA);
	
	txtB = new JTextArea();
	txtB.setBounds(170, 50, 150, 100);
	this.add(txtB);
	
	btnEnviar = new JButton("Enviar");
	btnEnviar.setBounds(220, 20, 100, 25);
	this.add(btnEnviar);
	
	btnEnviar.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent arg0) {
			txtA.append(txtConteudo.getText());
			txtConteudo.setText(null);
		}
	});
	
	btnCopiar = new JButton("Copiar");
	btnCopiar.setBounds(130, 160, 80, 25);
	this.add(btnCopiar);
	
	btnCopiar.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent arg0) {
			txtB.append(txtA.getText());
			
		}
	});
	
	btnLimpar1 = new JButton("Limpar");
	btnLimpar1.setBounds(10, 160, 80, 25);
	this.add(btnLimpar1);
	
	btnLimpar1.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent arg0) {
			txtA.setText(null);
		}
	});
	
	btnLimpar2 = new JButton("Limpar");
	btnLimpar2.setBounds(240, 160, 80, 25);
	this.add(btnLimpar2);
	
	btnLimpar2.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent arg0) {
			txtB.setText(null);
		}
	});
	
}

}
