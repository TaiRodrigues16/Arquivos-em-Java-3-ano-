package prova;

public class Principal {

	public static void main(String[] args) {
		
		Prova prova = new Prova("Prova");

	}

}
