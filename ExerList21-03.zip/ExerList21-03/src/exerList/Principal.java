package exerList;

public class Principal {

	public static void main(String[] args) {
		
		ExerList exer = new ExerList("Cat�logo");

	}

}
