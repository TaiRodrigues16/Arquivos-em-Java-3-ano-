package exerList;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;


public class ExerList extends JFrame {
	
	private JLabel lblNome, lbllist;
	private JTextField txtNome;
	private JComboBox comlistNome;
	private JButton btnAdd, btnRemov;
	String [] list = {"Maria"};
	
	public ExerList(String titulo){
		
		this.setLayout(null);
		
		this.setSize(400, 250);
		
		this.setTitle(titulo);
		
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		this.preencheJanela();
		
		this.setVisible(true);
		
	}
	
	public void preencheJanela(){
		
		JPanel panel = new JPanel();
		this.getContentPane().add(panel);
		panel.setLayout(null);
		panel.setBounds(0, 0, 400, 250);
		panel.setBackground(Color.WHITE);

		lblNome = new JLabel("Nome: ");
		lblNome.setBounds(10, 10, 80, 30);
		panel.add(lblNome);
		
		txtNome = new JTextField();
		txtNome.setBounds(50, 10, 150, 25);
		panel.add(txtNome);
		
		lbllist = new JLabel("Lista: ");
		lbllist.setBounds(10, 50, 80, 30);
		panel.add(lbllist);
		
		comlistNome = new JComboBox(list);
		comlistNome.setBounds(50, 50, 150, 25);
		comlistNome.setSelectedIndex(0);
		comlistNome.addActionListener(comlistNome);
		panel.add(comlistNome);
		
		btnAdd = new JButton("Adicionar");
		btnAdd.setBounds(230, 10, 100, 25);
		panel.add(btnAdd);
		
		btnAdd.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				comlistNome.addItem(txtNome.getText());
				txtNome.setText(null);
			}
		});
		
		btnRemov = new JButton("Remover");
		btnRemov.setBounds(230, 50, 100, 25);
		panel.add(btnRemov);
		
		btnRemov.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				System.out.println(comlistNome.getSelectedIndex());
				int index = comlistNome.getSelectedIndex();
				comlistNome.removeItemAt(index);
				
			}
		});
		
	}

}
