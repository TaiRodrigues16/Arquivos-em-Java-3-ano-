package Classes;

public class Principal {

	public static void main(String[] args) {
		
		//Criando uma janela
		Janela janelinha = new Janela("My Windows");
		
	}

}
