package Classes;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

//extends: especifica a qual classe sua classe vai herdar
//JFrame: classe respons�vel por se comportar como uma janela

public class Janela extends JFrame {
	//Criando os atributos e variav�is dos componentes
	private JLabel lblNome; 
	private JTextField txtNome;
	private JButton btnEnviar;
	private JLabel lblResposta;
	
	// Construtor
	public Janela( String titulo){
		// Definir o layout
		// null permite a voc� definir a posi��o exata
		// de cada componente em sua janela
		this.setLayout(null);
		
		// Definir o tamanho da janela
		// this.setSize (largura, altura)
		this.setSize(300, 200);
		
		// Dizendo para a janela FECHAR quando clicar no bot�o Fechar
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		// Dar um t�tulo para a Janela
		this.setTitle(titulo);
		
		this.preencheJanela();
		
		// --------------------------------------------------------
		// ---------------------- IMPORTANTE ----------------------
		// --------------------------------------------------------
		// O setVisible deve ser o �LTIMO m�todo chamado
		// Mostrar a janela na tela
		this.setVisible(true);
	}
	
	private void preencheJanela(){
		// Criando o Label
		lblNome = new JLabel("Nome: ");
		// setBounds ( x , y, largura, altura)
		lblNome.setBounds(10, 20, 100, 25);
		// Colocando-o na tela
		this.add(lblNome);
		lblNome.setText("Seu nome: ");
		
		//Criando o campo de texto
		txtNome = new JTextField();
		txtNome.setBounds(80, 20, 150, 25);
		this.add(txtNome);
		
		//txtNome.setText("Meu Nome");
		
		//Criando o bot�o
		btnEnviar = new JButton ("Enviar");
		btnEnviar.setBounds(80, 55, 100, 25);
		this.add(btnEnviar);
		
		lblResposta = new JLabel("Resposta");
		lblResposta.setBounds(100, 80, 100, 25);
		this.add(lblResposta);
		
		//Criando um ouvinte para vigiar as a��es do bot�o
		btnEnviar.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String nome = txtNome.getText();
				//Criando uma janelinha de alerta
				JOptionPane.showMessageDialog( null, "Boa Tarde, " + nome + "!");
				
				//Colocando o nome no novo Label
				lblResposta.setText(nome);
				
				// Limpar caixa de texto
				txtNome.setText(null);
			}
		});
		
	}

}
