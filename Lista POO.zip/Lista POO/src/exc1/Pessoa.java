package exc1;

public class Pessoa {
	
	String nome;
	String endereco;
	int telefone;
	
	public Pessoa(){
		this.nome = "Taiane Rodrigues";
		this.endereco = "Rua Capinopolis, numero 549";
		this.telefone = 992010963;
	}
	
	public void imprimir(){
		System.out.println("Nome: " + this.nome);
		System.out.println("Endereco: " + this.endereco);
		System.out.println("Telefone: " + this.telefone);
	}
	
}
