package exc1;

public class Principal {

	public static void main(String[] args) {

		Pessoa pessoa = new Pessoa();
		pessoa.imprimir();

	}

}
