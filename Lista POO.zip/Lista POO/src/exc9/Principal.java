package exc9;

public class Principal {

	public static void main(String[] args) {
		
		Moto moto = new Moto();
		moto.imprimir();
		
	}

}
