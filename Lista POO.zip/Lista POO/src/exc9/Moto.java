package exc9;

public class Moto {
	 
	String marca;
	String modelo;
	String cor;
	int marcha;
	int marchaMaior = 6;
	int marchaMenor = 0;
	boolean ligado;
	
	public Moto(){
		this.marca = "Yamahha";
		this.modelo = "Cripton";
		this.cor = "Preta";
		this.marcha = 0;
		this.ligado = true;
	}
	
	public int marchaAcima(){
		if (marcha < marchaMaior){
			marcha++;
		}
		return marcha;
	}
	
	public int marchaAbaixo(){
		if (marcha > marchaMenor){
			marcha --;
		}
		return marcha;
	}
	
	public void ligar(){
		this.ligado = true;
	}
	
	public void desligar(){
		this.ligado = false;
	}
	
	public void imprimir(){
		if(this.ligado == true){
			System.out.println("A moto esta ligada!");
			System.out.println("Marca: " + this.marca);
			System.out.println("Modelo: " + this.modelo);
			System.out.println("Cor: " + this.cor);
			System.out.println("Marcha: " + this.marcha);
			System.out.println("Marcha Acima: " + this.marchaAcima());
			System.out.println("Marcha Abaixo: " + this.marchaAbaixo());
			
		}else{
			System.out.println("A moto esta desligada!");
		}
		
		
	}
	
	

}
