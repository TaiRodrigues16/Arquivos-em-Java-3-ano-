package exc3;

public class Quadrado {
	
	int lado;
	int area;
	int perimetro;
	
	public Quadrado(){
		this.lado = 2;
		this.area = area;
		this.perimetro = perimetro;
	}
	
	public int calcularArea(){
		area = (lado * lado);
		return area;
	}
	
	public int calcularPerimetro(){
		perimetro = (4 * lado);
		return perimetro;
	}
	
	public void imprimir(){
		System.out.println("Lado: " + this.lado);
		System.out.println("Area: " + this.calcularArea());
		System.out.println("Perimetro: " + this.calcularPerimetro());
		
	}
	
	

}
