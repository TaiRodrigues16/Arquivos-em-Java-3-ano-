package exc3;

public class Principal {

	public static void main(String[] args) {
		
		Quadrado quadrado = new Quadrado();
		quadrado.imprimir();
		
	}

}
