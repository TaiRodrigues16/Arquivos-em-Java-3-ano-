package exc20;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Janela extends JFrame{
	
	Televisor tv;
	
	JLabel lblTvOn;
	JLabel lblTvOff;
	JButton btnPower;
	
	JLabel lblVolume;
	JLabel lblCanal;
	JButton btnCanalCima, btnCanalBaixo;
	JButton btnVolumeMax, btnVolumeMen;
	
	//Construtor
	public Janela(){
		this.setSize(600,600);
		this.setLayout(null);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		String titulo = null;
		this.setTitle("Televisor");
		//Criando o circuito da Televis�o
		tv = new Televisor();
		
		this.preencheJanela();
		
		// T�m de ser o �ltimo comando
		this.setVisible(true);
	}
	
	private void preencheJanela(){
		
		JPanel panel = new JPanel();
		this.getContentPane().add(panel);
		panel.setLayout(null);
		panel.setBounds(0, 0, 600, 600);
		panel.setBackground(Color.lightGray);
		
		ImageIcon img = new ImageIcon("Imagens/TvOn.jpg");
		lblTvOn = new JLabel(img);
		lblTvOn.setBounds(90, 50, 300, 170);
		panel.add(lblTvOn);
		lblTvOn.setVisible(false);
		
		img = new ImageIcon("Imagens/TvOff.jpg");
		lblTvOff = new JLabel(img);
		lblTvOff.setBounds(90, 50, 300, 170);
		panel.add(lblTvOff);
		//lblTvOff.setVisible(false);
		
		btnPower = new JButton("Power");
		btnPower.setBounds(180, 300, 80, 25);
		panel.add(btnPower);
		
		btnPower.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				tv.power();
				//Colocar para aparecer/ esconder as imagens
				tv.imprimir();
				
				if(tv.getLigado()==true){
					lblTvOn.setVisible(true);
					lblTvOff.setVisible(false);
				}
				else{
					lblTvOn.setVisible(false);
					lblTvOff.setVisible(true);
				}
				
			}
		});
		
		lblCanal = new JLabel("Canal: ");
		lblCanal.setBounds(10, 400, 80, 25);
		panel.add(lblCanal);
		lblCanal.setVisible(true);
		
		btnCanalCima = new JButton("CanalAcima");
		btnCanalCima.setBounds(250, 400, 110, 25);
		panel.add(btnCanalCima);
		
		btnCanalCima.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				tv.canalAcima();
				tv.imprimir();
				lblCanal.setText("Canal: " + tv.getCanal());
				
			}
		});
		
		btnCanalBaixo = new JButton("CanalBaixo");
		btnCanalBaixo.setBounds(100, 400, 100, 25);
		panel.add(btnCanalBaixo);
		
		btnCanalBaixo.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				tv.canalAbaixo();
				tv.imprimir();
				lblCanal.setText("Canal: " + tv.getCanal());
				
			}
		});
		
		lblVolume = new JLabel("Volume: ");
		lblVolume.setBounds(10, 450, 80, 25);
		panel.add(lblVolume);
		lblVolume.setVisible(true);
		
		btnVolumeMax = new JButton("Volume(+)");
		btnVolumeMax.setBounds(250, 450, 110, 25);
		panel.add(btnVolumeMax);
		
		btnVolumeMax.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				tv.volumeAcima();
				tv.imprimir();
				lblVolume.setText("Volume: " + tv.getVolume());
				
			}
		});
		
		btnVolumeMen = new JButton("Volume(-)");
		btnVolumeMen.setBounds(100, 450, 110, 25);
		panel.add(btnVolumeMen);
		
		btnVolumeMen.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				tv.volumeAbaixo();
				tv.imprimir();
				lblVolume.setText("Volume: " + tv.getVolume());
				
			}
		});
		
	}

}
