package exc20;

public class Televisor {
	
	private boolean ligado;
	private int canal;
	private int volume;
	
	private int numeroCanais = 50;
	private int volumeMaximo = 100;
	
	/**
	 * Construtor:
	 * � um m�todo respons�vel por inicializar o Objeto, com suas configura��es iniciais.
	 * Deve ter o mesmo nome da classe.
	 */
	
	/**
	 * M�TODOS
	 * Visibilidade tipoDeRetorno nomeDoMetodo (tipoParam1 nomeParam1, tipoParam2 nomeParam2){
	 * }
	 * Visibilidade: public / private (quem pode chamar este m�todo)
	 * tipoDeRetorno: int, boolean, String, void, etc...
	 */
	
	public Televisor(){
		this.ligado = false;
		this.canal = 3;
		this.volume = 10;
	}
	
	public Televisor(boolean ligado, int canal, int volume){
		// this.ligado refere-se ao atributo deste objeto ligado refere-se � vari�vel "ligado" passada por par�metro
		this.ligado = ligado;
		this.canal = canal;
		this.volume = volume;
	}
	
	public void ligar(){
		this.ligado = true;
	}
	
	public void desligar(){
		this.ligado = false;
	}
	
	
	 public void power(){
	 	if(this.ligado == true){
	 		this.ligado = false;
	  	}else{
	 this.ligado = true;
	 }
	  }
	 
	
	public void canalAcima(){
		this.canal++;
		if(this.canal > this.numeroCanais){
			this.canal = 1;
		}
	}
	
	public void canalAbaixo(){
		this.canal--;
		if(this.canal < 1){
			this.canal = this.numeroCanais;
		}
	}
	
	public boolean getLigado(){
		return this.ligado;
	}
	
	public int getCanal(){
		return this.canal;
	}
	
	public int volumeAcima(){
		if (volume < volumeMaximo){
			volume++;
		}
		return volume;
	}
	
	public int volumeAbaixo(){
		if (volume > volumeMaximo && volume != 0){
			volume --;
		}
		return volume;
	}
	
	public int getVolume(){
		return this.volume;
	}
	
	public void imprimir(){
		System.out.println("----------- TELEVISOR -----------");
		if(this.ligado == true){
			System.out.println("Ligado");
		}else{
			System.out.println("Desligado");
		}
		
		System.out.println("Canal: " + this.canal);
		System.out.println("Volume: " + this.volume);
		System.out.println("Volume Acima: " + this.volumeAcima());
		System.out.println("Volume Abaixo: " + this.volumeAbaixo());
		
	}

}
