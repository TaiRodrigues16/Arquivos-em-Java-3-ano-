package exc20;

public class Principal {

	public static void main(String[] args) {
		
		//Criar um Televisor
		/*
		 * tipoDoObjeto nomeDoObjeto = new tipoDoObjeto();
		 * Inst�ncia -> uma c�pia do objeto
		 */
		
		/*Televisor tvDaSala = new Televisor();
		tvDaSala.imprimir(); // chamando o m�todo imprimir
		
		//Outro Televisor
		Televisor tvDoQuarto = new Televisor(true, 75, 25);
		tvDoQuarto.canalAcima();
		tvDoQuarto.canalAcima();
		tvDoQuarto.imprimir(); */
		
		Janela janela = new Janela();

	}

}
