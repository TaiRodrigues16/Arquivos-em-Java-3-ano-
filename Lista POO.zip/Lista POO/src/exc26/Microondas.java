package exc26;

public class Microondas {
	
	boolean ligado;
	boolean  portaFechada;
	
	public Microondas(){
		this.ligado = true;
		this.portaFechada = true;
	}
	
	public void ligar(){
		if(portaFechada == true){
			this.ligado = true;
			System.out.println("O microondas esta ligado!");
		}	
	}
	
	public void desligar(){
		this.ligado = false;
		System.out.println("O microondas esta desligad!");
	}
	
	public void fecharPorta(){
		this.portaFechada = true;
	}
	
	public void abrirPorta(){
		this.portaFechada = false;
	}
	
	public void imprimir(){
		
		if(this.ligado == true){
			System.out.println("O microondas esta Ligado");
		}else{
			System.out.println("O microondas esta Desligado");
		}
		
		if(this.portaFechada == true){
			System.out.println("O microondas esta com a porta fechada");
		}else{
			System.out.println("O microondas esta com a porta aberta");
		}
	}

}
