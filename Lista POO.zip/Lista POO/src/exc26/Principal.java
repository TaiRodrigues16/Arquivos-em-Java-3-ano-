package exc26;

public class Principal {

	public static void main(String[] args) {
		
		Microondas micro = new Microondas();
		micro.imprimir();
		micro.ligar();

	}

}
