package exc7;

public class Circulo { 
	
	double raio;
	double area;
	double perimetro;
	
	double pi = 3.141516;
	
	public Circulo(){
		this.raio = 2.5;
		this.area = area;
		this.perimetro = perimetro;
	}
	
	//area: 19,634475... && perimetro: 15,70758
	
	public double calcularArea(){
		area = (pi * raio * raio);
		return area;
	}
	
	public double calcularPerimetro(){
		perimetro = (2 * pi * raio);
		return perimetro;
	}
	
	public void imprimir(){
		System.out.println("Raio: " + this.raio);
		System.out.println("Area: " + this.calcularArea());
		System.out.println("Perimetro: " + this.calcularPerimetro());
	}


}
