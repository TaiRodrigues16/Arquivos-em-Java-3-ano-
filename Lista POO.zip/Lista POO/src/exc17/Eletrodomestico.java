package exc17;

public class Eletrodomestico {
	
	boolean ligado;
	
	public Eletrodomestico(){
		this.ligado = true;
	}
	
	public void ligar(){
		this.ligado = true;
	}
	
	public void desligar(){
		this.ligado = false;
	}
	
	public void imprimir(){
		if(this.ligado == true){
			System.out.println("O eletrodomestico esta Ligado");
		}else{
			System.out.println("O eletrodomestico esta Desligado");
		}
	}

}
