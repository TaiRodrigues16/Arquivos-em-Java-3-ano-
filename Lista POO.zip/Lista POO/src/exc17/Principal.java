package exc17;

public class Principal {

	public static void main(String[] args) {
		
		Eletrodomestico eletro = new Eletrodomestico();
		eletro.imprimir();
		

	}

}
