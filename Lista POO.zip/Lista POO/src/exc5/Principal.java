package exc5;

public class Principal {

	public static void main(String[] args) {
		
		Retangulo retangulo = new Retangulo();
		retangulo.imprimir();
		
	}

}
