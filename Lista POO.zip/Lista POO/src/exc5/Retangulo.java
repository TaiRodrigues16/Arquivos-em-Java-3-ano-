package exc5;

public class Retangulo {
	
	//comprimento, largura, area e perimetro e, os m�todos calcularArea, calcularPerimetro e imprimir. 
	
	int comprimento;
	int largura;
	int area;
	int perimetro;
	
	public Retangulo(){
		this.comprimento = 2;
		this.largura = 4;
		this.area = area;
		this.perimetro = perimetro;
	}
	
	public int calcularArea(){
		area = (comprimento * largura);
		return area;
	}
	
	public int calcularPerimetro(){
		perimetro =  (2 * comprimento) + (2 * largura);
		return perimetro;
	}
	
	public void imprimir(){
		System.out.println("Comprimento: " + this.comprimento);
		System.out.println("Largura: " + this.largura);
		System.out.println("Area: " + this.calcularArea());
		System.out.println("Perimetro: " + this.calcularPerimetro());
	}

}
