package imc;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Imc extends JFrame {

		private JLabel lblPeso;
		private JLabel lblAltura;
		private JTextField txtPeso;
		private JTextField txtAltura;
		private JButton btnEnviar;
		private JLabel lblResposta;
		
		public Imc (String titulo){
			
			this.setLayout(null);
			
			this.setSize(300, 200);
			
			this.setDefaultCloseOperation(EXIT_ON_CLOSE);
			
			this.setTitle(titulo);
			
			this.preencheImc();
			
			this.setVisible(true);
			
		}
		
		public void preencheImc(){
			
			lblPeso = new JLabel("Peso: ");
			lblPeso.setBounds(10, 20, 100, 25);
			this.add(lblPeso);
			
			lblAltura = new JLabel("Altura: ");
			lblAltura.setBounds(20, 40, 200, 50);
			this.add(lblAltura);
			
			txtPeso = new JTextField();
			txtPeso.setBounds(80, 20, 150, 25);
			this.add(txtPeso);
			
			txtAltura = new JTextField();
			txtAltura.setBounds(80, 50, 150, 25);
			this.add(txtAltura);
			
			btnEnviar = new JButton("Enviar");
			btnEnviar.setBounds(80, 90, 100, 25);
			this.add(btnEnviar);
			
			lblResposta = new JLabel("Resposta");
			lblResposta.setBounds(100, 120, 100, 25);
			this.add(lblResposta);
			
			btnEnviar.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					
					double peso = Double.parseDouble(txtPeso.getText());
					double altura = Double.parseDouble(txtAltura.getText());
					double resposta;
					
					resposta = peso / (altura * altura);
					
					JOptionPane.showMessageDialog(null, "Calculo IMC: " + resposta + "!");
					
					lblPeso.setText(txtPeso.getText());
					lblAltura.setText(txtAltura.getText());
					
					txtPeso.setText(null);
					txtAltura.setText(null);
					
					
				}
			});
			
		}
		
		

}
