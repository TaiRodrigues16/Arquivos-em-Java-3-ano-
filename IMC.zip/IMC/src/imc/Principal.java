package imc;

public class Principal {

	public static void main(String[] args) {
		
		Imc imc = new Imc ("Calculo");

	}

}
