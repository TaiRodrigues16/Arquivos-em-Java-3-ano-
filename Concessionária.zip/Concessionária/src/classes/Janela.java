package classes;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter; 
import java.util.ArrayList;
import java.util.Collection;

import javax.swing.ButtonGroup;
import javax.swing.ButtonModel;
import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.CellEditorListener;
import javax.swing.event.ChangeEvent;
import javax.swing.event.TableModelEvent;
import javax.swing.table.DefaultTableModel;

import org.omg.CORBA.PUBLIC_MEMBER;

public class Janela extends JFrame{
	
	JLabel lblMarca, lblModelo, lblCor, lblPlaca, lblCombustivel;
	JComboBox cmbMarca, cmbCor;
	JTextField txtModelo, txtPlaca;
	JRadioButton radioGasolina, radioAlcool, radioFlex;
	ButtonGroup grupoCombustivel;
	JButton btnSalvar;
	JButton btnRemover;
	JButton btnEditar;
	JButton btnSave;
	String [] listMarca = {"Chevrolet", "Fiat", "Ford", "Volkswagen"};
	String [] listCor = {"Branco", "Prata", "Preto", "Vermelho"};
	int pos = -1;
	
	//Tabela
	String [] colunas = {"Marca", "Modelo", "Cor", "Placa", "Combustivel"};
	JTable tabela;
	DefaultTableModel dados;
	
	//Criando um vetor de carros
	ArrayList<Carro> carros = new ArrayList<Carro>();
	
	public Janela(){
		this.setSize(600, 500);
		this.setLayout(null);
		this.setTitle("Carros");
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		this.preencheJanela();
		
		this.setVisible(true);
	}
	
	public void preencheJanela(){
		// Marcas: Chevrolet, Fiat, Ford, Volkswagen
		// Cores: Branco, Prata, Preto, Vermelho
		// Combust�veis: Gasolina, Alcool, Flex
		// FA�AM O VISUAL!
		
		JPanel panel = new JPanel();
		this.getContentPane().add(panel);
		panel.setLayout(null);
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setBounds(0, 0, 600, 500);
		
		lblMarca = new JLabel("Marca:");
		lblMarca.setBounds(10, 20, 80, 25);
		panel.add(lblMarca);
		
		cmbMarca = new JComboBox(listMarca);
		cmbMarca.setBounds(60, 20, 100, 25);
		cmbMarca.setSelectedIndex(0);
		panel.add(cmbMarca);
		
		lblModelo = new JLabel("Modelo:");
		lblModelo.setBounds(10, 60, 80, 25);
		panel.add(lblModelo);
		
		txtModelo = new JTextField();
		txtModelo.setBounds(60, 60, 110, 25);
		panel.add(txtModelo);
		
		lblCor = new JLabel("Cor:");
		lblCor.setBounds(10, 100, 80, 25);
		panel.add(lblCor);
		
		cmbCor = new JComboBox(listCor);
		cmbCor.setBounds(60, 100, 100, 25);
		cmbCor.setSelectedIndex(0);
		panel.add(cmbCor);
		
		lblPlaca = new JLabel("Placa:");
		lblPlaca.setBounds(10, 140, 80, 25);
		panel.add(lblPlaca);
		
		txtPlaca = new JTextField();
		txtPlaca.setBounds(60, 140, 110, 25);
		panel.add(txtPlaca);
		
		lblCombustivel = new JLabel("Combust�vel:");
		lblCombustivel.setBounds(10, 180, 80, 25);
		panel.add(lblCombustivel);
		
		radioGasolina = new JRadioButton("Gasolina",false);
		radioGasolina.setBounds(90, 180, 80, 25);
		panel.add(radioGasolina);
		
		radioAlcool = new JRadioButton("Alcool",false);
		radioAlcool.setBounds(180, 180, 80, 25);
		panel.add(radioAlcool);
		
		radioFlex = new JRadioButton("Flex",false);
		radioFlex.setBounds(270, 180, 80, 25);
		panel.add(radioFlex);
		
		grupoCombustivel = new ButtonGroup();
		grupoCombustivel.add(radioGasolina);
		grupoCombustivel.add(radioAlcool);
		grupoCombustivel.add(radioFlex);
	
		/* Tabela
		 * Criei a Tabela
		 * Criei uma barra de rolagem com a tabela dentro
		 * Coloquei a barra de rolagem na janela
		 */
		dados = new DefaultTableModel(colunas, 0);
		tabela = new JTable(dados);
		JScrollPane rolagem = new JScrollPane(tabela);
		rolagem.setBounds(0, 280, 600, 200);
		panel.add(rolagem);
		
		btnSalvar = new JButton("Salvar");
		btnSalvar.setBounds(10, 240, 100, 25);
		panel.add(btnSalvar);
		
		btnSalvar.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				int marca = cmbMarca.getSelectedIndex();
				String modelo = txtModelo.getText();
				int cor = cmbCor.getSelectedIndex();
				String placa = txtPlaca.getText();
				
				String combustivel = "";
				if (radioAlcool.isSelected())
					combustivel = "Alcool";
				if (radioFlex.isSelected())
					combustivel = "Flex";
				if (radioGasolina.isSelected())
					combustivel = "Gasolina";
				
				//Criando um novo carro
				if (pos == -1){
				//Criando uma inst�ncia de um novo carro
				Carro car = new Carro(marca, modelo, cor, placa, combustivel);
				
				//Adicionando o Carro na tabela
				dados.addRow(car.getObjeto());
				
				//Adicionando o carro na lista de carros
				carros.add(car);
				}//Editando um novo carro
				else{
					Carro car;
					car = carros.get(pos);
					car.setMarca(marca);
					car.setModelo(modelo);
					car.setCor(cor);
					car.setPlaca(placa);
					car.setCombustivel(combustivel);
					
				}
				//JOptionPane.showMessageDialog(null, "Foi Salvo com Sucesso!");
				
				cmbMarca.setSelectedIndex(0);
				txtModelo.setText(null);
				cmbCor.setSelectedIndex(0);
				txtPlaca.setText(null);
				grupoCombustivel.clearSelection();
				
				
			}
		});
		
		btnEditar = new JButton("Editar");
		btnEditar.setBounds(150, 240, 100, 25);
		panel.add(btnEditar);
		
		btnEditar.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent a) {
				
				pos = tabela.getSelectedRow();
				
				int marca = carros.get(pos).getMarca();
				cmbMarca.setSelectedIndex(marca);
				String modelo = carros.get(pos).getModelo();
				txtModelo.setText(modelo);
				int cor = carros.get(pos).getCor();
				cmbCor.setSelectedIndex(cor);
				String placa = carros.get(pos).getPlaca();
				txtPlaca.setText(placa);
				String combustivel = carros.get(pos).getCombustivel();
				
				combustivel = "";
				if (combustivel == "Alcool"){
					radioAlcool.setSelected(true);
				}
				if (combustivel == "Flex"){
					radioFlex.setSelected(true);
				}
				if (combustivel == "Gasolina"){
					radioGasolina.setSelected(true);
				}
				
			}
		});
		
		btnRemover = new JButton("Remover");
		btnRemover.setBounds(290, 240, 100, 25);
		panel.add(btnRemover);
		
		btnRemover.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				int pos = tabela.getSelectedRow();
				//Removendo da Tabela
				dados.removeRow(pos);
				//Removendo da lista de carros
				carros.remove(pos);
				
			}
		});
		
		btnSave = new JButton("SaveDados");
		btnSave.setBounds(430, 240, 130, 25);
		panel.add(btnSave);
		
		btnSave.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				FileWriter arq;
				Carro car;
				try{
					arq = new FileWriter("Carrinho/car.txt");
					PrintWriter pw = new PrintWriter(arq);
					for (int i = 0; i < carros.size(); i++) {
						car = carros.get(i);
						pw.println(car.listMarca[getMarca()]);
						pw.println(car.getModelo());
						pw.println(car.listCor[getCor()]);
						pw.println(car.getPlaca());
						pw.println(car.getCombustivel());
					}
					arq.close();
				}catch(IOException e){
					e.printStackTrace();
				}
			
				
			}

			private int getCor() {
				// TODO Auto-generated method stub
				return 0;
			}

			private int getMarca() {
				// TODO Auto-generated method stub
				return 0;
			}
		});
		
}

}
