package classes;

public class Principal {

	public static void main(String[] args) {
		
		Janela janela = new Janela();

	}

}
