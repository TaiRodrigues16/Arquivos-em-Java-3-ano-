package classes;

import javax.swing.DefaultCellEditor;

public class Carro {
	
	private int marca;
	private String modelo;
	private int cor;
	private String placa;
	private String combustivel;
	
	String [] listMarca = {"Chevrolet", "Fiat", "Ford", "Volkswagen"};
	String [] listCor = {"Branco", "Prata", "Preto", "Vermelho"};
	
	public Carro(int marca, String modelo, int cor, String placa, String combustivel){
		this.marca = marca;
		this.modelo = modelo;
		this.cor = cor;
		this.placa = placa;
		this.combustivel = combustivel;
	}
	
	public int getMarca(){
		return this.marca;
	}
	
	public void setMarca(int marca){
		this.marca = marca;
	}
	
	public String getModelo(){
		return this.modelo;
	}
	
	public void setModelo(String modelo){
		this.modelo = modelo;
	}
	
	public int getCor(){
		return this.cor;
	}
	
	public void setCor(int cor){
		this.cor = cor;
	}
	
	public String getPlaca(){
		return this.placa;
	}
	
	public void setPlaca(String placa){
		this.placa = placa;
	}
	
	public String getCombustivel(){
		return this.combustivel;
	}
	
	public void setCombustivel(String combustivel){
		this.combustivel = combustivel;
	}
	
	public Object[] getObjeto(){
		Object [] obj = {listMarca[getMarca()], getModelo(), listCor[getCor()], getPlaca(), getCombustivel()};
		
		return obj;
	}

	

	

	
	

}
