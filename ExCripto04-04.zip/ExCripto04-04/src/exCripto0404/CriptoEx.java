package exCripto0404;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class CriptoEx {

	    public static void main(String[] args) throws FileNotFoundException {
	    	FileInputStream stream = new FileInputStream("C://Users/Taiane/workspace/3� ano/ExCripto04-04/src/exCripto0404/new 3.txt");
	        Scanner arq = new Scanner(stream);
			while (arq.hasNextLine()) {
			   String linha = arq.nextLine();
			  
			   String nova = linha.replaceAll("g", "E").replaceAll("i", "N").replaceAll("l", "T").replaceAll("k", "A")
			   .replaceAll("x", "O").replaceAll("f", "V").replaceAll("w", "P").replaceAll("q", "R").replaceAll("a", "D")
			   .replaceAll("z", "S").replaceAll("j", "Q").replaceAll("y", "U").replaceAll("t", "G").replaceAll("d", "I")
			   .replaceAll("m", "L").replaceAll("b", "C").replaceAll("s", "M").replaceAll("n", "F").replaceAll("v", "H")
			   .replaceAll("c", "K").replaceAll("p", "B").replaceAll("h", "J").replaceAll("r", "Y").replaceAll("u", "Z")
			   .replaceAll("o", "X");
			  
				System.out.println(nova);
			    
			}
			arq.close();
			
	    }
	    
	    
	    
}

