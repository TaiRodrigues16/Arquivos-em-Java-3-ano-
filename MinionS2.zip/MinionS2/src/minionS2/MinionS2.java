package minionS2;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.GeneralPath;

import javax.swing.JPanel;

public class MinionS2 extends JPanel{

	@Override
	protected void paintComponent(Graphics graphic) {
		super.paintComponent(graphic);
		
		Graphics2D g = (Graphics2D) graphic;
		
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		//I
		BasicStroke grossa = new BasicStroke(15, BasicStroke.CAP_ROUND, BasicStroke.JOIN_BEVEL);
		g.setStroke(grossa);
		g.drawLine(70, 90, 70, 400);
		
		grossa = new BasicStroke(15, BasicStroke.CAP_ROUND, BasicStroke.JOIN_BEVEL);
		g.setStroke(grossa);
		g.drawLine(10, 90, 130, 90);
		g.drawLine(10, 400, 130, 400);
		//S2
		Color corC1 = new Color(252, 0, 0);
		Color corC2 = new Color(255, 46, 46);
		GradientPaint grad = new GradientPaint(0, 0, corC1, 30, 100, corC2, true);
		g.setPaint(grad);
		g.fillOval(200, 80, 200, 200);
		g.fillOval(370, 80, 200, 200);
		
		double[][] pontos = {
			//x    y     x     y	
			{210, 226.5}, {560, 226.5}, {380, 410}	
		};
			
		GeneralPath quad = new GeneralPath();
		//Movendo o pincel para o primeiro ponto
		quad.moveTo(pontos [0][0], pontos [0][1]);
			
		for (int i = 0; i < pontos.length; i++){
			quad.lineTo(pontos[i][0], pontos[i][1]);
		}
		quad.closePath();
		g.fill(quad);
		
		Color corM = new Color(255, 221, 3);
		g.setColor(corM);
		//g.fillOval(700, 50, 350, 400);
		//x inicial, y inicial, Largura, Altura, anguloInicial, quantidadeGraus
		//Corpo
		g.fillArc(760, 170, 250, 300, 0, 180);
		g.fillRoundRect(760, 300, 250, 260, 50, 50);
		//Bra�o
		grossa = new BasicStroke(40, BasicStroke.CAP_ROUND, BasicStroke.JOIN_BEVEL);
		g.setStroke(grossa);
		g.drawLine(770, 420, 680, 420);
		g.drawArc(1000, 420, 40, 90, 0, 100);
		//Dedos
		g.setColor(Color.BLACK);
		g.drawLine(675, 420, 640, 430);
		g.drawLine(675, 420, 650, 390);
		g.drawLine(1040, 486, 1040, 510);
		g.drawLine(1040, 487, 1070, 492);
		grossa = new BasicStroke(40, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER);
		g.setStroke(grossa);
		//Pulso
		g.drawLine(700, 420, 660, 420);
		g.drawLine(1040, 466, 1040, 485);
		//Manga
		g.drawLine(740, 420, 730, 420);
		grossa = new BasicStroke(40, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER);
		g.setStroke(grossa);
		g.setColor(Color.WHITE);
		g.drawLine(770, 420, 740, 420);
		g.drawArc(960, 410, 85, 50, 0, 90);
		g.setColor(Color.BLACK);
		grossa = new BasicStroke(10, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER);
		g.setStroke(grossa);
		g.drawLine(1015, 436, 1065, 436);
		
		//P�s
		grossa = new BasicStroke(40, BasicStroke.CAP_ROUND, BasicStroke.JOIN_BEVEL);
		g.setStroke(grossa);
		g.drawLine(850, 560, 850, 610);
		g.drawLine(850, 610, 810, 610);
		g.drawLine(910, 560, 910, 610);
		g.drawLine(950, 610, 910, 610);
		grossa = new BasicStroke(40, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_BEVEL);
		g.setStroke(grossa);
		
		Color cor;
		cor = new Color(3, 70, 138);
		g.setColor(cor);
		g.drawLine(850, 560, 850, 563);
		g.drawLine(910, 560, 910, 563);
		
		//Roupa
		grossa = new BasicStroke(40, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL);
		g.setStroke(grossa);
		g.setColor(Color.WHITE);
		double[][] ponts = {
				//x    y     x     y	
				{760,390}, {750,560}, {1000,560}, {1020,550}, {1010,390}, {930,430}, {840,430}
			};
				
			GeneralPath roupa = new GeneralPath();
			//Movendo o pincel para o primeiro ponto
			roupa.moveTo(ponts [0][0], ponts [0][1]);
				
			for (int i = 0; i < ponts.length; i++){
				roupa.lineTo(ponts[i][0], ponts[i][1]);
			}
			roupa.closePath();
			g.fill(roupa);
			g.setColor(Color.lightGray);
			grossa = new BasicStroke(3, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_BEVEL);
			g.setStroke(grossa);
			g.draw(roupa);
			
			//Bolso
			grossa = new BasicStroke(5, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_BEVEL);
			g.setStroke(grossa);
			g.drawLine(926, 440, 926, 558);
			
			//Gola
			g.setColor(Color.BLACK);
			grossa = new BasicStroke(40, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_ROUND);
			g.setStroke(grossa);
			g.drawLine(770, 390, 850, 420);
			g.drawLine(920, 420, 1000, 390);
			
			grossa = new BasicStroke(10, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_ROUND);
			g.setStroke(grossa);
			g.drawLine(770, 460, 810, 460);
			
			//Bot�es
			g.fillOval(910, 460, 10, 10);
			g.fillOval(860, 460, 10, 10);
			g.fillOval(910, 490, 10, 10);
			g.fillOval(860, 490, 10, 10);
			g.fillOval(910, 520, 10, 10);
			g.fillOval(860, 520, 10, 10);
			
			//�culos
			cor = new Color(135, 134, 131);
			g.setColor(cor);
			grossa = new BasicStroke(20, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
			g.setStroke(grossa);
			g.drawLine(763, 289, 1004, 289);
			g.drawLine(763, 305, 1004, 305);
			cor = new Color(71, 70, 68);
			g.setColor(cor);
			grossa = new BasicStroke(5, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
			g.setStroke(grossa);
			g.drawLine(758, 297, 1008, 297);
			
			//Olhos
			cor = new Color(135, 134, 131);
			g.setColor(cor);
			g.fillOval(798, 255, 95, 95);
			g.fillOval(878, 255, 95, 95);
			g.setColor(Color.WHITE);
			g.fillOval(813, 270, 65, 65);
			g.fillOval(893, 270, 65, 65);
			//g.fillOval(815, 270, 60, 60);
			cor = new Color(0, 153, 3);
			g.setColor(cor); //verde
			grad = new GradientPaint(0, 0, Color.green, 5, 40, cor, true);
			g.setPaint(grad);
			g.fillOval(820, 280, 40, 40);
			g.fillOval(897, 280, 40, 40);
			g.setColor(Color.BLACK);
			g.fillOval(825, 295, 10, 10);
			g.fillOval(905, 295, 10, 10);
			
			//Boca
			cor = new Color(224, 0, 0);
			g.setColor(cor);
			g.fillArc(855, 350, 70, 50, 5, -185);
			
			//Chapeu
			grossa = new BasicStroke(40, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_MITER);
			g.setStroke(grossa);
			cor = new Color(237, 237, 237);
			g.setColor(cor);
			g.drawLine(780, 225, 990, 225);
			g.setColor(Color.WHITE);
			g.fillRoundRect(759, 120, 253, 90, 5, 180);
			g.fillOval(730, 20, 150, 150);
			g.fillOval(810, 10, 150, 150);
			g.fillOval(890, 20, 150, 150);
			g.setColor(Color.BLACK);
			g.fillOval(800, 120, 40, 80);
			g.fillOval(865, 120, 40, 80);
			g.fillOval(930, 120, 40, 80);
			
			//Bigode
			g.setColor(Color.BLACK);
			grossa = new BasicStroke(5, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_MITER);
			g.setStroke(grossa);
			g.drawLine(876, 369, 860, 359);
			g.drawLine(860, 359, 850, 369);
			g.drawLine(850, 369, 820, 349);
			
			g.drawLine(896, 369, 910, 359);
			g.drawLine(910, 359, 920, 369);
			g.drawLine(920, 369, 950, 349);
			
			//Banana do Bolso
			cor = new Color(252, 204, 45);
			g.setColor(cor);
			grossa = new BasicStroke(20, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_MITER);
			g.setStroke(grossa);
			g.drawLine(788, 446, 788, 440);
			grossa = new BasicStroke(20, BasicStroke.CAP_ROUND, BasicStroke.JOIN_MITER);
			g.setStroke(grossa);
			g.drawLine(788, 444, 788, 435);
			/*grossa = new BasicStroke(10, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_MITER);
			g.setStroke(grossa);
			g.drawLine(788, 444, 788, 428);*/
			g.setColor(Color.BLACK);
			grossa = new BasicStroke(10, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_MITER);
			g.setStroke(grossa);
			g.drawLine(788, 427, 788, (int) 426.5);
			grossa = new BasicStroke(1, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_MITER);
			g.setStroke(grossa);
			g.drawLine(783, 456, 783, 428);
			g.drawLine(793, 456, 793, 428);
			
			//Seta
			g.setColor(Color.black);
			grossa = new BasicStroke(120, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_MITER);
			g.setStroke(grossa);
			g.drawLine(80, 540, 400, 540);
			
			//Palavra
			g.setColor(Color.YELLOW);
			//B
			grossa = new BasicStroke(15, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_MITER);
			g.setStroke(grossa);
			g.drawLine(70, 505, 70, 585);
			g.fillArc(70, 500, 50, 50, 0, 360);
			g.fillArc(70, 538, 50, 50, 0, 360);
			//A
			grossa = new BasicStroke(10, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_MITER);
			g.setStroke(grossa);
			g.drawLine(135, 505, 135, 585);
			g.drawLine(135, 502, 175, 502);
			g.drawLine(135, 542, 175, 542);
			g.drawLine(175, 505, 175, 585);
			//N
			g.drawLine(195, 505, 195, 585);
			g.drawLine(195, 505, 230, 585);
			g.drawLine(230, 505, 230, 585);
			//A
			g.drawLine(250, 505, 250, 585);
			g.drawLine(250, 502, 280, 502);
			g.drawLine(250, 542, 280, 542);
			g.drawLine(280, 505, 280, 585);
			//N
			g.drawLine(300, 505, 300, 585);
			g.drawLine(300, 505, 330, 585);
			g.drawLine(330, 505, 330, 585);
			//A
			g.drawLine(350, 505, 350, 585);
			g.drawLine(350, 502, 380, 502);
			g.drawLine(350, 542, 380, 542);
			g.drawLine(380, 505, 380, 585);
			//!
			g.drawLine(400, 505, 400, 555);
			g.fillOval(393, 570, 15, 15);
			
			//Bolinhas do B
			g.setColor(Color.BLACK);
			g.fillArc(80, 510, 30, 30, 0, 360);
			g.fillArc(80, 547, 30, 30, 0, 360);
			
			//Ponta da Seta
			g.setColor(Color.BLACK);
			double[][] pontoS = {
					//x    y     x     y	
					{420, 420}, {420, 653}, {573, 536}	
				};
					
				GeneralPath set = new GeneralPath();
				//Movendo o pincel para o primeiro ponto
				set.moveTo(pontoS [0][0], pontoS [0][1]);
					
				for (int i = 0; i < pontoS.length; i++){
					set.lineTo(pontoS[i][0], pontoS[i][1]);
				}
				set.closePath();
				g.fill(set);
				
			//Espatula
			cor = new Color(0, 7, 110);
			g.setColor(cor);
			grossa = new BasicStroke(15, BasicStroke.CAP_ROUND, BasicStroke.JOIN_MITER);
			g.setStroke(grossa);
			g.drawLine(662, 469, 640, 300);
			grossa = new BasicStroke(16, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_MITER);
			g.setStroke(grossa);
			cor = new Color(143, 144, 148);
			Color cor2 = new Color(219, 219, 219);
			grad = new GradientPaint(0, 0, cor, 5, 40, cor2, true);
			g.setPaint(grad);
			g.drawLine(651, 386, 640, 300);
			g.fillRoundRect(610, 280, 70, 70, 10, 30);
			grossa = new BasicStroke(5, BasicStroke.CAP_ROUND, BasicStroke.JOIN_MITER);
			g.setStroke(grossa);
			cor = new Color(17, 169, 250);
			g.setColor(cor);
			g.drawLine(625, 293, 625, 340);
			g.drawLine(645, 293, 645, 340);
			g.drawLine(665, 293, 665, 340);
			
		
	}

}
