package minionS2;

import java.awt.Color;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;

public class Janela extends JFrame implements MouseListener{
	
	public Janela(){
		this.setSize(1500, 800);
		this.setTitle("Minion S2");
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		MinionS2 minion = new MinionS2();
		minion.setBounds(0, 0, 1500, 800);
		this.add(minion);
		Color cor2;
		cor2 = new Color(17, 169, 250);
		minion.setBackground(cor2);
		minion.addMouseListener(this);
		this.setVisible(true);
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		System.out.println(e.getX() + ", " + e.getY());
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}
