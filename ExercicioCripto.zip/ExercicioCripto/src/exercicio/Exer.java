package exercicio;

public class Exer {
	
	private int chave;
	
	public Exer(int chave){
		this.chave = chave;
	}
	
	public String descriptografia(String msg){
		String msgCriptografada = "";
		
		for (int i = 0; i < msg.length(); i++) {
			if(msg.charAt(i) != ' '){
				int letra = (int)msg.charAt(i);
				//cache(convers�o) transformar inteiro do meu caracter e tranforma em letra
				letra -= chave;
				if(letra < 97 && letra < 123){
					letra = 122-(96 - letra);
				}
				msgCriptografada += (char)letra;
			}
			else msgCriptografada += ' ';
		}
		return msgCriptografada;
	}

}
