package exercicio;

import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		
		Exer exer = new Exer(12);
		
		String descriptografar = exer.descriptografia("fqdoquda mza uzra");
		
		System.out.println(descriptografar);
	}

}
