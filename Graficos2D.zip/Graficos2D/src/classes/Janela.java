package classes;

import javax.swing.JFrame;

public class Janela extends JFrame{
	
	public Janela(){
		this.setSize(600, 600);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setTitle("Desenho");
		
		//Aqui vai o desenho
		Desenho des = new Desenho();
		des.setBounds(0, 0, 600, 600);
		this.add(des);
		this.setVisible(true);
		
	}

}
