package classes;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.geom.GeneralPath;

import javax.swing.JPanel;

public class Desenho extends JPanel{
	
	@Override
	protected void paintComponent(Graphics graph) {
		// Chamando o m�todo do pai, que permite que vc customize o seu visual
		super.paintComponent(graph);
		
		//g ser� o seu papel
		Graphics2D g = (Graphics2D) graph;
		//Alterar com do pincel
		/*g.setColor(Color.RED);
		
		// x inicial, y inicial, x final, y final
		g.drawLine(225, 225, 375, 225);
		g.drawLine(375, 225, 375, 375);
		g.drawLine(375, 375, 225, 375);
		g.drawLine(225, 375, 225, 225);
		
		g.fillRect(100, 100, 50, 75);
		g.setColor(Color.BLUE);
		g.drawRect(100, 100, 50, 75);
		
		// x inicial, y inicial, largura, altura
		g.drawOval(400, 400, 100, 100);*/
		
		g.setColor(Color.green);
		GradientPaint grad1 = new GradientPaint(0, 0, Color.green, 125, 100,Color.GREEN, true);
		g.setPaint(grad1);
		double[][] pontos = {
			//x    y     x     y	
			{200, 300}, {500, 300}, {500, 500}, {200, 500}	
		};
		
		GeneralPath quad = new GeneralPath();
		//Movendo o pincel para o primeiro ponto
		quad.moveTo(pontos [0][0], pontos [0][1]);
		
		for (int i = 0; i < pontos.length; i++){
			quad.lineTo(pontos[i][0], pontos[i][1]);
		}
		quad.closePath();
		g.fill(quad);
		
		g.setColor(Color.yellow);
		
		double[][] quadrado = {
			{350,300}, {500,400}, {350,500}, {200,400}	
		};
		
		GeneralPath quad1 = new GeneralPath();
		//Movendo o pincel para o primeiro ponto
		quad1.moveTo(quadrado [0][0], quadrado [0][1]);
		
		for (int j = 0; j < quadrado.length; j++){
			quad1.lineTo(quadrado[j][0], quadrado[j][1]);
		}

		quad1.closePath();
		g.fill(quad1);
		
		GradientPaint grad = new GradientPaint(0, 0, Color.blue, 125, 100, Color.cyan, true);
		g.setPaint(grad);
		// x inicial, y inicial, largura, altura
		g.fillOval(270, 320, 160, 160);
		
		g.setColor(Color.BLUE);
		//g.setColor(Color.RED);
		g.drawLine(160, 20, 185, 70);
		g.drawLine(185, 70, 240, 70);
		g.drawLine(240, 70, 195, 110);
		g.drawLine(195, 110, 215, 170);
		g.drawLine(215, 170, 160, 140);
		g.drawLine(160, 140, 115, 170);
		g.drawLine(115, 170, 130, 110);
		g.drawLine(130, 110, 90, 70);
		g.drawLine(90, 70, 140, 70);
		g.drawLine(140, 70, 160, 20);
		
		
		
		
	}

}
