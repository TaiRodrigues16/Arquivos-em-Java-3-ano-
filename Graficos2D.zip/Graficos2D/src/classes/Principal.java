package classes;

public class Principal {

	public static void main(String[] args) {
		
		Janela janelinha = new Janela();

	}

}
