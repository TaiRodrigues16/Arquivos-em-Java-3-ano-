package Classes;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.util.Scanner;

import javax.swing.tree.ExpandVetoException;

public class RSA {

	public static void main(String[] args) throws IOException
	{
		BufferedReader arquivo = new BufferedReader(new FileReader("arquivo/primos.txt"));
		int cont = 0;
		String linha = "";
		
		long p, q, n, z, d, e;
		p = (int)(Math.random()*9592);
		q = (int)(Math.random()*9592);
		
		System.out.println(p + ", " + q);
		
		do
		{
			linha = arquivo.readLine();
			cont+=1;
			if(cont == p) p = Integer.parseInt(linha);
			if(cont == q) q = Integer.parseInt(linha);
		}while(linha != null);
		
		arquivo.close();
		
		
		n = p * q;
		z = (p-1) * (q-1);
		d = encontraPrimo(z);
		e = encontraE(d, z);
		d = euclides_ext(e, z, 1);
		
		System.out.println(e + " * " + d + " mod "+ z + " = " + (e*d)%z);
		
		System.out.println("p: " + p + ", q: " + q + ", n: " + n + ", z: " + z + ", d:" + d + ", e:" + e);
		
		String text = "oi";
		String recebe = palavraParaBinario(text);
		
		System.out.println(palavraParaBinario(text));
		
		BigInteger numero = new BigInteger(recebe,2);
		//numero.modPow(BigInteger.valueOf(e), BigInteger.valueOf(n));
		
		BigInteger cript = numero.modPow(BigInteger.valueOf(e), BigInteger.valueOf(n));
		
		System.out.println(numero);
		System.out.println(cript);
		
		BigInteger descript = cript.modPow(BigInteger.valueOf(d), BigInteger.valueOf(n));
		
		System.out.println(descript);
		
		
		String bin = descript.toString(2);
		bin = "0" + bin;
		String parte1 = bin.substring(0, 8);
		int d1 = Integer.parseInt(parte1, 2);
		String parte2 = bin.substring(8, 16);
		int d2 = Integer.parseInt(parte2, 2);
		
		char r1 = (char)d1;
		String palavra = "";
		palavra+= r1;
		r1 = (char)d2;
		palavra+=r1;
		
		
		System.out.println(palavra);
		
	}
	public static String palavraParaBinario(String text)
	{
		String bin = "";
		for (int i = 0; i < text.length(); i++) 
		{
			bin = bin + formataBinario((Integer.toBinaryString((int)text.charAt(i))));
		}
		return formataBinario(bin);
	}
	public static String formataBinario(String s)
	{
		int dif = 8 - s.length();
		for (int i = 0; i < dif; i++) {
			s = "0"+s;
		}
		return s;
	}
	
	public static long encontraE(long d, long z)
	{
		long e = 0, i=1;
		while(e == 0)
		{
			if(((i * d) % z) == 1) return i;
			i++;
		}
		return 0;
	}
	
	public static long encontraPrimo(long z)
	{
		long d = 0, i = 2;
		while(d == 0)
		{
			if(mdc(i,z) == 1) return i;
			i++;
		}
		return 0;
	}
	
	public static long mdc(long n1, long n2)
	{
		 long z=1,mdc, dividendo, divisor;
		 
		 dividendo = n1;
		 divisor = n2;
		 
		 while ( z !=0 )
		 {
			 z = dividendo % divisor;
			 dividendo = divisor;
			 divisor = z;
		 };
		 
		 mdc = dividendo;
		 
		 return mdc;

	}
	public static long mod(long a, long b)
	{
	    long r = a % b;

	    /* Uma corre�� � necess�ria se r e b n�o forem do mesmo sinal */

	    /* se r for negativo e b positivo, precisa corrigir */
	    if ((r < 0) && (b > 0))
	   return (b + r);

	    /* Se ra for positivo e b negativo, nova correcao */
	    if ((r > 0) && (b < 0))
	   return (b + r);

	    return (r);
	}

	public static long euclides_ext(long a, long b, long c)
	{
	    long r;

	    r = mod(b, a);

	    if (r == 0) {
	   return (mod((c / a), (b / a)));   // retorna (c/a) % (b/a)
	    }

	    return ((euclides_ext(r, a, -c) * b + c) / (mod(a, b)));
	}

}
