package trabalhoGui;

public class Principal {

	public static void main(String[] args) {
		
		Trabalho trab = new Trabalho("Turismo.com");

	}

}
