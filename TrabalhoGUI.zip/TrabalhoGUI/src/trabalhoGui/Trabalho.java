package trabalhoGui;

import java.awt.Color;
import java.awt.Container;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JSlider;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Trabalho extends JFrame {
	
	private JLabel lblNome, lblObs, lblCids, lblPagar, lblPessoas, lblPass, lblGostar, lblOlhaAqui, lblEmail;
	private JTextField txtNome,campoTexto, txtEmail;
	private JTextArea txtObs;
	private JComboBox comList;
	private JCheckBox boleto, cartao;
	private JRadioButton PesNada, PesOne, PesMais;
	private JPasswordField senha;
	private JSlider slider;
	private JButton btnEnviar, btnLimpar;
	String[] Cidlist = {"Amsterd�","Argentina","Ibiza","Londres","Madagascar","New York","Paris","Roma","Rom�nia","Turquia"};
	private JSpinner spinner;
	private JLabel lblIdade;
	
	
	public Trabalho(String titulo){
		
		this.setLayout(null);
		
		this.setContentPane(new Container());
		
		this.setSize(500, 600);
		
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	
		this.setTitle(titulo);
		
		this.preencheJanela();
		
		this.setVisible(true);
	
	}
	
	public void preencheJanela(){
		
		JPanel panel = new JPanel();
		this.getContentPane().add(panel);
		panel.setLayout(null);
		panel.setBounds(0, 0, 500, 600);
		panel.setBackground(Color.lightGray);
		//panel.setVisible(false);
		
		lblNome = new JLabel("Nome: ");
		// setBounds ( x , y, largura, altura)
		lblNome.setBounds(10, 20, 100, 25);
		// Colocando-o na tela
		panel.add(lblNome);
		
		txtNome = new JTextField();
		txtNome.setBounds(60, 20, 150, 25);
		panel.add(txtNome);
		
		lblIdade = new JLabel("Idade: ");
		lblIdade.setBounds(250, 20, 80, 25);
		panel.add(lblIdade);
		
		spinner = new JSpinner();
		spinner.setBounds(300, 20, 40, 25);
		panel.add(spinner);
		
		lblCids = new JLabel("Cidades: ");
		// setBounds ( x , y, largura, altura)
		lblCids.setBounds(10, 60, 100, 25);
		// Colocando-o na tela
		panel.add(lblCids);
		
		comList = new JComboBox(Cidlist);
		comList.setBounds(70, 60, 100, 25);
		comList.setSelectedIndex(0);
		comList.addActionListener(comList);
		panel.add(comList);
		
		lblPagar = new JLabel("Pagamento: ");
		// setBounds ( x , y, largura, altura)
		lblPagar.setBounds(10, 100, 100, 25);
		// Colocando-o na tela
		panel.add(lblPagar);
		
		boleto = new JCheckBox("Boleto");
		boleto.setBounds(80, 100, 100, 20);
		panel.add(boleto);
		
		cartao = new JCheckBox("Cart�o");
		cartao.setBounds(180, 100, 100, 20);
		panel.add(cartao);
		
		lblPessoas = new JLabel("Acompanhantes: ");
		// setBounds ( x , y, largura, altura)
		lblPessoas.setBounds(10, 140, 100, 25);
		// Colocando-o na tela
		panel.add(lblPessoas);
		
		PesNada = new JRadioButton("0", false);
		PesNada.setBounds(110, 140, 100, 20);
		panel.add(PesNada);
		
		PesOne = new JRadioButton("1", false);
		PesOne.setBounds(110, 160, 100, 20);
		panel.add(PesOne);
		
		PesMais = new JRadioButton("Mais", false);
		PesMais.setBounds(110, 180, 100, 20);
		panel.add(PesMais);
		
		lblGostar = new JLabel ("Interesse: ");
		lblGostar.setBounds(10, 220, 100, 25);
		panel.add(lblGostar);
		
		slider = new JSlider();
		slider.setBounds(80, 220, 200, 25);
		panel.add(slider);
	
		lblObs = new JLabel("Obs: ");
		// setBounds ( x , y, largura, altura)
		lblObs.setBounds(10, 280, 100, 25);
		// Colocando-o na tela
		panel.add(lblObs);
		
		txtObs = new JTextArea();
		txtObs.setBounds(50, 280, 350, 100);
		panel.add(txtObs);
		
		lblOlhaAqui = new JLabel("SE CADASTRE EM NOSSA AG�NCIA E RECEBA OFERTAS DI�RIAS!");
		// setBounds ( x , y, largura, altura)
		lblOlhaAqui.setBounds(10, 410, 500, 25);
		// Colocando-o na tela
		panel.add(lblOlhaAqui);
		
		lblEmail = new JLabel("E-mail: ");
		// setBounds ( x , y, largura, altura)
		lblEmail.setBounds(10, 440, 100, 25);
		// Colocando-o na tela
		panel.add(lblEmail);
		
		txtEmail = new JTextField();
		txtEmail.setBounds(60, 440, 400, 25);
		panel.add(txtEmail);
		
		lblPass = new JLabel("Crie uma senha: ");
		lblPass.setBounds(10, 500, 100, 25);
		panel.add(lblPass);
		
		senha = new JPasswordField(15);
		senha.setBounds(110, 500, 150, 25);
		panel.add(senha);
		
		btnEnviar = new JButton ("Enviar");
		btnEnviar.setBounds(300, 500, 100, 25);
		panel.add(btnEnviar);
		
		btnEnviar.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String nome = txtNome.getText();
				//Criando uma janelinha de alerta
				JOptionPane.showMessageDialog( null, "Cadastro feito " + nome + "!");
				JOptionPane.showMessageDialog( null, "BEM VINDO A TURISMO.COM!");
		
				// Limpar caixa de texto
				txtNome.setText(null);
				txtObs.setText(null);
				txtEmail.setText(null);
				senha.setText(null);
			}
			
		});
	
		
		
	}

}
